# Duke Office

[![CI](https://github.com/extend-hq/duke-office/actions/workflows/check.yml/badge.svg)](https://github.com/extend-hq/duke-office/actions/workflows/check.yml) [![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

Rust parsers for Word, PowerPoint and [OpenDocument](docs/opendocument.md) text and presentations, shared Office chart and artwork rendering, and browser WASM bindings. Powers [React DOCX](https://github.com/extend-hq/react-docx), [React XLSX](https://github.com/extend-hq/react-xlsx), and [React PPTX](https://github.com/extend-hq/react-pptx). XLSX workbook parsing and calculation use DukeSheets in React XLSX.

The crates and Rust imports use the `duke-` and `duke_` prefixes. Existing consumers must update their dependency names and imports to migrate. The first releases under these names retain the preceding version numbers. Historical benchmark images retain the labels captured at measurement time.

The former `rust-*` Office packages are deprecated by this project and no longer receive CI builds or releases. Use the [replacement crate mapping](RELEASING.md#retired-crate-names) when migrating existing dependencies.

## Packages

| Crate | Purpose | Version | Downloads | API docs |
| --- | --- | --- | --- | --- |
| [duke-office-charts](crates/duke-office-charts) | Render Office chart definitions to SVG | [![duke-office-charts version](https://img.shields.io/crates/v/duke-office-charts.svg)](https://crates.io/crates/duke-office-charts) | [![duke-office-charts downloads](https://img.shields.io/crates/d/duke-office-charts.svg)](https://crates.io/crates/duke-office-charts) | [![duke-office-charts documentation](https://docs.rs/duke-office-charts/badge.svg)](https://docs.rs/duke-office-charts) |
| [duke-office-art](crates/duke-office-art) | Render Office pictures, shapes and connectors | [![duke-office-art version](https://img.shields.io/crates/v/duke-office-art.svg)](https://crates.io/crates/duke-office-art) | [![duke-office-art downloads](https://img.shields.io/crates/d/duke-office-art.svg)](https://crates.io/crates/duke-office-art) | [![duke-office-art documentation](https://docs.rs/duke-office-art/badge.svg)](https://docs.rs/duke-office-art) |
| [duke-odf](crates/duke-odf) | Read OpenDocument packages, styles, text and drawings for the parsers | [![duke-odf version](https://img.shields.io/crates/v/duke-odf.svg)](https://crates.io/crates/duke-odf) | [![duke-odf downloads](https://img.shields.io/crates/d/duke-odf.svg)](https://crates.io/crates/duke-odf) | [![duke-odf documentation](https://docs.rs/duke-odf/badge.svg)](https://docs.rs/duke-odf) |
| [duke-office-charts-wasm](crates/duke-office-charts-wasm) | WebAssembly bindings for Office chart rendering | [![duke-office-charts-wasm version](https://img.shields.io/crates/v/duke-office-charts-wasm.svg)](https://crates.io/crates/duke-office-charts-wasm) | [![duke-office-charts-wasm downloads](https://img.shields.io/crates/d/duke-office-charts-wasm.svg)](https://crates.io/crates/duke-office-charts-wasm) | [![duke-office-charts-wasm documentation](https://docs.rs/duke-office-charts-wasm/badge.svg)](https://docs.rs/duke-office-charts-wasm) |
| [duke-pages](crates/duke-pages) | Parse Word documents into a structured document model | [![duke-pages version](https://img.shields.io/crates/v/duke-pages.svg)](https://crates.io/crates/duke-pages) | [![duke-pages downloads](https://img.shields.io/crates/d/duke-pages.svg)](https://crates.io/crates/duke-pages) | [![duke-pages documentation](https://docs.rs/duke-pages/badge.svg)](https://docs.rs/duke-pages) |
| [duke-pages-wasm](crates/duke-pages-wasm) | WebAssembly bindings for the Word parser | [![duke-pages-wasm version](https://img.shields.io/crates/v/duke-pages-wasm.svg)](https://crates.io/crates/duke-pages-wasm) | [![duke-pages-wasm downloads](https://img.shields.io/crates/d/duke-pages-wasm.svg)](https://crates.io/crates/duke-pages-wasm) | [![duke-pages-wasm documentation](https://docs.rs/duke-pages-wasm/badge.svg)](https://docs.rs/duke-pages-wasm) |
| [duke-slides](crates/duke-slides) | Parse PowerPoint presentations into a structured slide model | [![duke-slides version](https://img.shields.io/crates/v/duke-slides.svg)](https://crates.io/crates/duke-slides) | [![duke-slides downloads](https://img.shields.io/crates/d/duke-slides.svg)](https://crates.io/crates/duke-slides) | [![duke-slides documentation](https://docs.rs/duke-slides/badge.svg)](https://docs.rs/duke-slides) |
| [duke-slides-wasm](crates/duke-slides-wasm) | WebAssembly bindings for the PowerPoint parser | [![duke-slides-wasm version](https://img.shields.io/crates/v/duke-slides-wasm.svg)](https://crates.io/crates/duke-slides-wasm) | [![duke-slides-wasm downloads](https://img.shields.io/crates/d/duke-slides-wasm.svg)](https://crates.io/crates/duke-slides-wasm) | [![duke-slides-wasm documentation](https://docs.rs/duke-slides-wasm/badge.svg)](https://docs.rs/duke-slides-wasm) |

Install native parsers with `cargo add duke-pages` or `cargo add duke-slides`; their Rust imports are `duke_pages` and `duke_slides`. Each crate's README contains usage and API details.

For browser charts, install `@extend-ai/duke-office-charts`:

```js
import { loadOfficeCharts } from "@extend-ai/duke-office-charts/full";

const renderer = await loadOfficeCharts();
const svg = renderer.renderChart(chartXml, options);
```

The default entry includes 2D bar, line, area and scatter charts; `/full` adds the other supported families. Unsupported layouts can return `null`. [Office fonts](packages/office-fonts) load separately from chart WASM.

## Development

```bash
rustup target add wasm32-unknown-unknown
cargo test --workspace --locked
cargo check --workspace --locked --target wasm32-unknown-unknown
npm run check:browser
```

CI uses Rust 1.93.1 and Node.js 24. Install `wasm-pack` and run `npm run build:browser` after changing chart WASM sources; see the [release guide](RELEASING.md) for generated assets and versioning.

| Work | Start here |
| --- | --- |
| Word parsing, source references and serialization | [duke-pages](crates/duke-pages), [structured export](docs/structured-export.md) |
| PowerPoint parsing and slide models | [duke-slides](crates/duke-slides) |
| Shared chart and artwork rendering | [duke-office-charts](crates/duke-office-charts), [duke-office-art](crates/duke-office-art), [art architecture](docs/office-art-architecture.md) |
| Browser loaders and generated chart WASM | [browser](browser), [chart WASM bindings](crates/duke-office-charts-wasm) |
| Benchmarks and visual comparisons | [DOCX parser tools](scripts/parser-benchmark/README.md), [PPTX parser tools](scripts/pptx-benchmark/README.md), [chart tools](scripts/chart-fidelity/README.md), [art tools](scripts/image-fidelity/README.md) |
| Versions and publication from main | [Release guide](RELEASING.md) |

Parser and shared renderer fixes belong here; React layout and interaction changes belong in the viewer repositories. Rust crates and npm packages have independent versions.

## Packages, benchmarks, and chart accuracy

Retained captures below identify their measured versions and dates. They do not establish current-release parity with Microsoft Office.

### Excel charts

[![Microsoft Excel and React XLSX side by side across 24 chart examples](docs/readme-assets/excel-chart-overview.png)](docs/excel-chart-comparisons.md)

November 5, 2026: **382/382 charts rendered across 43 workbooks**, with **381 native Excel reference pairs** and 48 gallery cases. Lighting, label placement and map geometry still differ.

| Gallery | Examples |
| --- | ---: |
| [Bars, lines, areas and secondary axes](docs/readme-assets/excel-chart-bars-lines-areas.png) | 8 |
| [Pies, exploded slices and multiple rings](docs/readme-assets/excel-chart-pies-and-rings.png) | 8 |
| [Scatter, bubbles, radar, error bars and stock](docs/readme-assets/excel-chart-scatter-radar-stock.png) | 8 |
| [Modern charts and filled maps](docs/readme-assets/excel-chart-modern-charts.png) | 8 |
| [3D areas, pies, cones, cylinders, pyramids and surfaces](docs/readme-assets/excel-chart-three-dimensional.png) | 8 |
| [Shadows, bevels, labels and trendline equations](docs/readme-assets/excel-chart-formatting-and-effects.png) | 8 |

[Method and limitations](docs/excel-chart-comparisons.md) · [Measurements](docs/readme-assets/excel-chart-comparison.csv) · [Provenance](docs/readme-assets/excel-chart-provenance.json)

### Word charts

[![Microsoft Word and react-docx side by side for 28 chart and map examples](docs/readme-assets/word-chart-overview.png)](docs/readme-assets/word-chart-overview.png)

November 4, 2026, React DOCX 0.14.0: **155/157 charts rendered**; two volume-stock combinations produced no image. The overview shows 28 pairs; the galleries retain every case. Ink overlap measures shared visible ink; color match requires RGB agreement within 16 levels per channel over the ink union.

| Chart group | Viewer images | Median ink overlap | Median color match |
| --- | ---: | ---: | ---: |
| [Bars, lines, areas and pies](docs/readme-assets/word-chart-bars-lines-areas-and-pies.png) | 20/20 | 96.8% | 77.2% |
| [Scatter, bubble, radar and stock](docs/readme-assets/word-chart-scatter-bubble-radar-and-stock.png) | 15/17 | 88.0% | 46.9% |
| [3D columns, bars, areas and lines](docs/readme-assets/word-chart-3d-columns-bars-areas-and-lines.png) | 19/19 | 68.3% | 39.3% |
| [Surfaces and split pies](docs/readme-assets/word-chart-surfaces-and-split-pies.png) | 13/13 | 96.0% | 88.8% |
| [Axes, statistics and missing data](docs/readme-assets/word-chart-axes-statistics-and-missing-data.png) | 21/21 | 82.1% | 62.5% |
| [Fills, colors and markers](docs/readme-assets/word-chart-fills-colors-and-markers.png) | 12/12 | 98.6% | 49.9% |
| [Modern charts and filled maps](docs/readme-assets/word-chart-modern-charts-and-filled-maps.png) | 8/8 | 95.3% | 94.7% |
| [Map areas and projections](docs/readme-assets/word-chart-map-areas-and-projections.png) | 24/24 | 86.3% | 82.5% |
| [Map data and styling](docs/readme-assets/word-chart-map-data-and-styling.png) | 16/16 | 95.7% | 92.6% |
| [Independent Open XML SDK sample](docs/readme-assets/word-chart-independent-open-xml-sdk-sample.png) | 7/7 | 56.2% | 39.3% |

[Method and limitations](docs/chart-comparisons.md) · [Measurements](docs/readme-assets/word-chart-comparison.csv)

### Office Art

[![Microsoft Word versus Duke Office Art: SmartArt, WordArt, 3D emoji models, icons, ink and 3D shapes](docs/readme-assets/word-officeart-expanded-overview.png)](docs/office-art-comparisons.md)

November 6, 2026: **30 cases** through the native DOCX adapter. 3D models use saved Office previews; SmartArt uses saved drawing trees. WordArt, projected 3D shapes and ink are rendered, with remaining font, warp, shading and texture differences. Artistic-effect controls measure cache preservation.

| Gallery | Cases |
| --- | ---: |
| [3D models, emoji and SmartArt](docs/readme-assets/word-officeart-expanded-models-and-smartart.png) | 7 |
| [WordArt, warped text, extrusion, bevels and materials](docs/readme-assets/word-officeart-expanded-wordart-and-3d.png) | 12 |
| [SVG icons, shapes, ink and cached artistic effects](docs/readme-assets/word-officeart-expanded-icons-shapes-and-ink.png) | 11 |

[Method and gaps](docs/office-art-comparisons.md) · [Measurements](docs/readme-assets/word-officeart-expanded-comparison.csv) · [Provenance](docs/readme-assets/word-officeart-expanded-provenance.json)

[![Microsoft Word and React DOCX picture appearance side by side](docs/readme-assets/word-officeart-overview.png)](docs/readme-assets/word-officeart-overview.png)

[![Microsoft Word and React DOCX shapes and connectors side by side](docs/readme-assets/word-officeart-shapes.png)](docs/readme-assets/word-officeart-shapes.png)

November 5, 2026, workspace DOCX/WASM 0.2.9 candidate: **61 controlled picture, group and shape cases**, compared at fixed native page coordinates.

| Matrix | Cases at 96% color agreement | Median | All-case mean |
| --- | ---: | ---: | ---: |
| [Pictures and effects](docs/readme-assets/word-picture-comparison.csv) | 37/40 | 100.00% | 94.11% |
| [Group transforms](docs/readme-assets/word-group-comparison.csv) | 4/5 | 98.55% | 97.67% |
| [Shapes and connectors](docs/readme-assets/word-shape-comparison.csv) | 10/16 | 97.51% | 93.78% |

Color agreement uses the visible-ink union. The 96–97% target is not met across all cases. A separate full-document check of **123 drawings** reaches **50.00% mean agreement**, with **0/123 at 96%**; another **206 drawings lack native references**.

[Coverage and method](docs/picture-coverage.md) · [Document measurements](docs/readme-assets/word-art-document-comparison.csv) · [Document provenance](docs/readme-assets/word-art-document-provenance.json) · [SmartArt coverage](docs/smartart-coverage.md) · [Manual fixtures and tools](scripts/image-fidelity/README.md)

### DOCX parser benchmarks

November 2, 2026: **1,000 documents**, with latency measured on the **999 inputs completed by all four parsers**. Native parsing/model construction excludes file reads, startup, serialization and browser layout. Each point represents a document's median warm parse time; p95 is across those medians.

![Native DOCX median and p95 latency for all four libraries](docs/readme-assets/docx-core-optimized-20261102-latency-docx-summary.png)

![DOCX latency scatter plots by input size, source paragraph count, and source feature count](docs/readme-assets/docx-core-optimized-20261102-latency-docx-scatter.png)

Text and feature scores use independent source-XML references; they measure extraction, not rendering fidelity. A separate 25-document Word reference sample is included in the full report.

[![DOCX feature recall heatmap: duke-pages, docx-rs, office_oxide and undoc across 23 source-XML checks](docs/readme-assets/docx-optimized-20261102-feature-recall.png)](docs/readme-assets/docx-optimized-20261102-feature-recall.png)

Each cell is recall against the independent source-XML reference on all 1,000 inputs, on a fixed 0–100% scale. Gray cells are checks a parser's output model cannot express. duke-pages (November 2 build) leads or ties on 18 of 23 checks and matches all 1,069 source image occurrences to retained payload bytes. Its largest gap is exact horizontal-span anchors (96.492%); literal span text reaches 99.946%. The superseded image node-count proxy remains in the [original scoring details](docs/docx-benchmarks.md).

[Results, feature recall and methodology](docs/docx-benchmarks.md) · [Benchmark tools](scripts/parser-benchmark/README.md) · [Source-reference data](crates/duke-pages/benchmarks/optimized-20261102/accuracy.json) · [Word-reference data](crates/duke-pages/benchmarks/word-reference-20261103/summary.json)

### PPTX parser benchmarks

[![PPTX feature recall heatmap: duke-slides and seven other PowerPoint parsers across 19 source-XML checks](docs/readme-assets/pptx-current-20261109-feature-recall.png)](docs/readme-assets/pptx-current-20261109-feature-recall.png)

November 9, 2026, duke-slides 0.1.7 in its eager default (commit `d665c48`, phase `current-20261109`): **eight parsers on 630 OOXML inputs**, scored against **628 independent source-XML references**. Each cell is recall on a fixed 0–100% scale; failed parses count as zero, and gray cells are checks a parser's output model cannot express. These measure extraction, not rendering fidelity.

On the 610 common nonempty inputs, default parsing measures **1.112 ms median and 13.288 ms p95**, versus Office Oxide’s 0.323 ms and 3.884 ms. These are shared-machine native timings; duke-slides includes model construction and generated artwork.

The **retained follow-up implementation for 0.2.2** measures **0.982 ms median / 14.999 ms p95** on the same 610 inputs, versus the 0.2.1 implementation at **1.099 / 15.720 ms**, Office Oxide **0.338 / 3.701 ms** and undoc **0.337 / 10.207 ms** in that run: a median paired speedup of 1.106× over 0.2.1 with unchanged output. That run shared the machine with heavy unrelated load, so its absolute times are not comparable with the figures above. This preserves the full eager model and source-feature coverage, including the 0.2.1 fix for foreign-qualified text-style attributes. The revised target is a sub-1 ms median with verified feature advantages; this first result below 1 ms stays unconfirmed until a quiet-machine run reproduces it. The matrix above retains its original build and scoring provenance. [Latest audit and receipts](docs/pptx-parser-audit.md).

duke-slides leads or ties on 18 of 19 checks. Image payload occurrences reach 93.791%: all 113 misses are pictures with a preferred SVG alternative, where duke-slides selects the SVG and retains the fallback bitmap separately, while the reference counts only the primary blip.

[Specification audit, timing and methodology](docs/pptx-parser-audit.md) · [Benchmark tools](scripts/pptx-benchmark/README.md) · [Measurements](docs/readme-assets/pptx-current-20261109-feature-recall.csv) · [Provenance](docs/readme-assets/pptx-current-20261109-feature-recall.json)

## License

[MIT](LICENSE). Bundled dependencies and data have additional [notices](THIRD-PARTY-NOTICES.txt), [font licenses](FONT-DATA-LICENSE), and [map licenses](MAP-DATA-LICENSE); check individual crates for their notices.
